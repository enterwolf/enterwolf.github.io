import random
import time

Hi_Msg = {"Русский" : "Добро пожаловать в 'Угадай число'!\nЯ загадал число от 1 до ста. Попробуй угадать его за 6 попыток!\n",
          "English" : "Welcome to 'Guess the Number' game!\nI have selected a number between 1 and 100. Try to guess it in 6 attemps!\n"
          }
Loss = {"Русский" : "Вы проиграли!\n",
        "English" : "You lost!\n"
        }
Win = {"Русский" : "Вы выиграли!\n",
        "English" : "You won!\n"
        }
Less = {"Русский" : "Слишком мало!\n",
        "English" : "Too low!\n"
        }
More = {"Русский" : "Слишком много!\n",
        "English" : "Too high!\n"
        }
EnterSearchGameOne = {"Русский" : "Введите число: ",
                      "English" : "Enter your guess: "
                      }

def guess_number(system_language):
    number_to_guess = random.randint(1, 100)
    attempts = 0
    print(Hi_Msg[system_language])

    while attempts <= 6:
        guess = int(input(EnterSearchGameOne[system_language]))
        attempts = attempts + 1

        if guess < number_to_guess:
            print(Less[system_language])
        elif guess > number_to_guess:
            print(More[system_language])
        else:
            print(Win[system_language])
            time.sleep(1)
            return
    if attempts == 6:
        print(Loss[system_language])
        time.sleep(1)
        return
