import time

list_of_commands = {"Русский" : "/username - Получите Ваш псевдоним\n/time - Узнайте время\n/system_language - Просмотрите свой язык\n/closeterminal - Закрыть терминал \n", 
                    "English" : "/username - Get your username\n/time - Get time\n/system_language - Veiw your system language\n/closeterminal - Close terminal\n"
                   }

def CommandTerminal(system_language, username):
    while True:
        print("©Enter Games Corporation 2025.\nTo get list of command use /commands")
        files_terminal = "system52/EnterOS/%s\n"
        command = input(files_terminal % username)

        if command == "/commands":
            print(list_of_commands[system_language])
        elif command == "/username":
            print(username)
        elif command == "/closeterminal":
            break
        elif command == "/time":
            print(time.asctime())
        elif command == "/system_language":
            print(system_language)               