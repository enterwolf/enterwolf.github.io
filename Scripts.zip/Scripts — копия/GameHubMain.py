import GuessNumber
PlayGameList = {"Русский" : "Во что вы хотите поиграть? Чтобы выйти, напишите /close\n1. Угадай число\n",
            "English" : "What do you want to play? To exit, write /close\n1. Guess number\n"
            }

def GameHubMainFunc(system_language):
    PlayGame = input(PlayGameList[system_language])
    if PlayGame == "/close":
        return
    elif PlayGame == "1":
        GuessNumber.guess_number(system_language)