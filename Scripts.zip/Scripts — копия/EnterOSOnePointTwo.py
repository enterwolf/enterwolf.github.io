import EnterBrowser
import Terminal
import GameHubMain

enter_username = {"Русский" : "Введите имя\n", 
                  "English" : "Enter username\n"
                  }
app_select_application = {"Русский" : "1. Терминал\n2. EnterBrowser\n3. Игры\n", 
                          "English" : "1. Terminal\n2. EnterBrowser\n3. Game Hub\n"
                          }

#Applications
def main(system_language, username):
    result = Application(system_language)
    if result == "1":
        Terminal.CommandTerminal(system_language, username)
    elif result == "2":
        EnterBrowser.EnterBrowser(system_language)
    elif result == "3":
        GameHubMain.GameHubMainFunc(system_language)
    main(system_language, username)

def Application(system_language):
    select_application = input(app_select_application[system_language])
    return select_application

####################################################################################           

#Basic code
system_language = input("Choose a language\n")
username = input(enter_username[system_language])

if system_language == "Русский":
    hi_message = "Здравствуйте %s!"
    print(hi_message % username)
    main("Русский", username)
elif system_language == "English":
    hi_message = "Hello %s!"
    print(hi_message % username)
    main("English", username)