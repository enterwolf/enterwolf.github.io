import webbrowser

browser_successfull_open = {"Русский" : "Успешно открыт, для закрытия напишите br.close", 
                            "English" : "Successfully, to close print br.close"
                            }
browser_enter_search = {"Русский" : "Введите запрос\n", 
                        "English" : "Enter search\n"
                        }

def EnterBrowser(system_language):
        print(browser_successfull_open[system_language])
        search = input(browser_enter_search[system_language])
        if search == "br.close":
                return
        else:
                webbrowser.open_new(search)